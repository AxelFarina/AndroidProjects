package com.cursosandroidant.notes

data class Note(var id:Long = 0, var description:String = "", var isFinished: Boolean = false)